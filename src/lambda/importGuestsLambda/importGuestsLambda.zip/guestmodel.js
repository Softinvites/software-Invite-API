import { Schema, model } from "mongoose";
const GuestSchema = new Schema({
    fullname: { type: String, required: true },
    TableNo: { type: String, required: false },
    email: { type: String, required: false, },
    phone: { type: String, required: false },
    message: { type: String, required: true },
    others: { type: String, required: false },
    qrCode: { type: String, required: false },
    qrCodeData: { type: String, required: false },
    qrCodeBgColor: { type: String, default: "255,255,255" },
    qrCodeCenterColor: { type: String, default: "0,0,0" },
    qrCodeEdgeColor: { type: String, default: "0,0,0" },
    eventId: { type: Schema.Types.ObjectId, ref: "Event", required: true },
    status: {
        type: String,
        enum: ["pending", "checked-in"],
        default: "pending",
    },
    checkedIn: { type: Boolean, default: false },
    imported: { type: Boolean, default: false },
}, { timestamps: true });
export const Guest = model("Guest", GuestSchema);
